/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model_Lomba;

/**
 *
 * @author PC PRAKTIKUM
 */
public class Model_Lomba {
    private String Judul;
    private Double alur;
    private Double orisinalitas;
    private Double pemilihanKata;
    private Double nilai;

    public String getJudul() {
        return Judul;
    }

    public void setJudul(String Judul) {
        this.Judul = Judul;
    }

    public Double getAlur() {
        return alur;
    }

    public void setAlur(Double alur) {
        this.alur = alur;
    }

    public Double getOrisinalitas() {
        return orisinalitas;
    }

    public void setOrisinalitas(Double orisinalitas) {
        this.orisinalitas = orisinalitas;
    }

    public Double getPemilihanKata() {
        return pemilihanKata;
    }

    public void setPemilihanKata(Double pemilihanKata) {
        this.pemilihanKata = pemilihanKata;
    }

    public Double getNilai() {
        return nilai;
    }

    public void setNilai(Double nilai) {
        this.nilai = nilai;
    }

}
